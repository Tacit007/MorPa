-- phpMyAdmin SQL Dump
-- version 4.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 06, 2016 at 08:06 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `MorPa`
--

-- --------------------------------------------------------

--
-- Table structure for table `feed`
--

CREATE TABLE IF NOT EXISTS `feed` (
  `id` int(11) NOT NULL,
  `feedURL` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feed`
--

INSERT INTO `feed` (`id`, `feedURL`) VALUES
(53, 'http://dou.ua/lenta/feed/');

-- --------------------------------------------------------

--
-- Table structure for table `newsEntry`
--

CREATE TABLE IF NOT EXISTS `newsEntry` (
  `id` int(11) NOT NULL,
  `title` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `link` varchar(500) CHARACTER SET utf8 DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsEntry`
--

INSERT INTO `newsEntry` (`id`, `title`, `link`, `date`) VALUES
(11, '18 февраля, Киев — APL annual introduction course', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/GcxaiCe2ZFg/', '2016-01-21 11:46:24'),
(12, 'Junior дайджест: курси, стажування, інтернатура. Січень-лютий’16', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/N9AQelZLP8M/', '2016-01-21 10:00:00'),
(13, 'DOU Проектор: Yes Cart — e-commerce платформа', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/RjOYVQ_BP8g/', '2016-01-20 13:27:55'),
(14, '26 января, Киев — Product Club at Grammarly', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/hmlp1q2Opb0/', '2016-01-20 10:51:05'),
(15, 'ИТ как сфера работы: почему ее выбирают и каково в ней работать (опрос)', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/xV57jP8rE34/', '2016-01-20 10:00:00'),
(16, '25 января, Киев — Курс "DevOps для сисадминов"', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/gtl1QsLh3r0/', '2016-01-19 20:07:00'),
(17, '8 февраля, Киев — Курсы для С# /.NET разработчиков в CyberBionic Systematics', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/fzmMg3UZUfA/', '2016-01-19 14:04:58'),
(18, 'Беседа с Тарасом Середой, инженером машинного обучения в Depositphotos', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/4VoD7-8dhSc/', '2016-01-19 14:00:06'),
(19, 'Рейтинг языков программирования №7: PHP уходит с пьедестала', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/uk4OyJzHSaU/', '2016-01-19 10:00:00'),
(20, '26 января — Online курс тестирования Softengi Training Center', 'http://feedproxy.google.com/~r/DevelopersOrgUa/~3/NZRCVYc8T9g/', '2016-01-18 21:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `login` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `cityID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `cityID`) VALUES
(0, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feed`
--
ALTER TABLE `feed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsEntry`
--
ALTER TABLE `newsEntry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feed`
--
ALTER TABLE `feed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `newsEntry`
--
ALTER TABLE `newsEntry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
